package com.example.user.hw1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Activity1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity1)
    }
}
